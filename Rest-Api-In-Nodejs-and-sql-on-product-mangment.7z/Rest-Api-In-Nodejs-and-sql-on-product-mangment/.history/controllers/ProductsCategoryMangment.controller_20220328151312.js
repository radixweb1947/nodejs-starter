const ProductsCategoryMangment = require('../models/ProductsCategoryMangment.model');
const HttpException = require('../utils/HttpException.utils');
const { validationResult } = require('express-validator');
const dotenv = require('dotenv');
dotenv.config();

/******************************************************************************
 *                              Events Controller
 ******************************************************************************/
class ProductsCategoryMangment {
    getProductCategory= async (req, res, next) => {
        let ProductCategoryList = await ProductsCategoryMangment.findEvents();
        if (!ProductCategoryList.length) {
            throw new HttpException(404, 'Events not found');
        }
        res.send(ProductCategoryList);
    };

    createCategory = async (req, res, next) => {
        this.checkValidation(req);
        var sql = `INSERT INTO event_details (event_name, event_starting_time, event_duration,user_id) VALUES ("${req.body.event_name}", "${req.body.event_starting_time}", "${req.body.event_duration}",1)`;
        const result = await ProductsCategoryMangment.findEvents({custom_query:sql});
        if (!result) {
            throw new HttpException(500, 'Something went wrong');
        }
        res.status(201).send('Events was created!');
    };
}



/******************************************************************************
 *                               Export
 ******************************************************************************/
module.exports = new ProductsCategoryMangment;