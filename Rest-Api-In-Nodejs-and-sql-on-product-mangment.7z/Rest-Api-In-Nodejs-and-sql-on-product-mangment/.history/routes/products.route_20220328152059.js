const express = require('express');
const router = express.Router();
const ProductsMangment = require('../controllers/ProductsMangment.controller');
const auth = require('../middleware/auth.middleware');
const awaitHandlerFactory = require('../middleware/awaitHandlerFactory.middleware');
router.get('/upcoming_event', auth(), awaitHandlerFactory(ProductsMangment.getProducts));
router.post('/create_event', awaitHandlerFactory(ProductsMangment.addProducts));
module.exports = router;