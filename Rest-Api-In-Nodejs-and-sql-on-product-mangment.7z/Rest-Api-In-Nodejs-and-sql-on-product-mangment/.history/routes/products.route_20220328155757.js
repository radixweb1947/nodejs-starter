const express = require('express');
const router  = express.Router();
const ProductsMangment    = require('../controllers/ProductsMangment.controller');
const awaitHandlerFactory = require('../middleware/awaitHandlerFactory.middleware');
const createProductsSchema = require('../middleware/ProductsValidator.middleware');
router.get('/getProducts',awaitHandlerFactory(ProductsMangment.getProducts));
router.post('/addProducts', createProductsSchema(ProductsMangment.addProducts));
module.exports = router;