# Rest-Api-In-Nodejs-and-sql-on-event-mangment

**Create a product management CRUD APIs(use any Database you have learned in course)::**

  i.   Create Product
  
  ii.  Update Product
  
  iii. List Product(with pagination  and sorting)
  
  iv.  Delete Product
  

**Product would have below fields::**

i. name

ii. category

iii. price

iv. description

v. status


================

For use this code need to install

node

npm

mysql

===================================

Pre-requirement 
Import node_api.sql file in phpmyadmin
Update db-connection.js file like your current db user , host, password etc.
after than you need to postman or thunder client or  api test other platform to test the api.


Dummy data to insert
====================================
{
    "product_category_id": 1,
    "product_name": "Standard Bussiness Cards",
    "product_description": "Creative Business Cards to Impress Clients!",
    "price": 10,
    "status": "1"
}
You can refer below documention to how to use our api
https://documenter.getpostman.com/view/17828788/UVyoUxSx

